var TSC = TSC || {};

TSC.embedded_config_xml = '<x:xmpmeta tsc:version="2.0.1" xmlns:x="adobe:ns:meta/" xmlns:tsc="http://www.techsmith.com/xmp/tsc/">\
   <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/" xmlns:xmpG="http://ns.adobe.com/xap/1.0/g/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:tscDM="http://www.techsmith.com/xmp/tscDM/" xmlns:tscIQ="http://www.techsmith.com/xmp/tscIQ/" xmlns:tscHS="http://www.techsmith.com/xmp/tscHS/" xmlns:stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#" xmlns:stFnt="http://ns.adobe.com/xap/1.0/sType/Font#" xmlns:exif="http://ns.adobe.com/exif/1.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\
      <rdf:Description dc:date="2024-12-15 10:54:49 PM" dc:source="Camtasia,9.0.4,enu" dc:title="module20_4" tscDM:firstFrame="module20_4_First_Frame.png" tscDM:originId="67823403-5526-4B23-8647-20BF45EAEF59" tscDM:project="module20_4">\
         <xmpDM:duration xmpDM:scale="1/1000" xmpDM:value="119100"/>\
         <xmpDM:videoFrameSize stDim:unit="pixel" stDim:h="900" stDim:w="1416"/>\
         <tsc:langName>\
            <rdf:Bag>\
               <rdf:li xml:lang="en-US">English</rdf:li></rdf:Bag>\
         </tsc:langName>\
         <xmpDM:Tracks>\
            <rdf:Bag>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="Caption" xmpDM:frameRate="f1000" xmpDM:trackName="Captioning" stFnt:fontFamily="Arial" tscDM:fontSize="30" tscDM:bgOpacity="0.750000" tscDM:position="overlay">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="0" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Yếu tố thứ ba của việc kết thúc khóa học là chuyển tiếp sinh viên sang chương \\par trình giảng dạy trong tương lai.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="6000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Quá trình chuyển tiếp giúp học sinh tạo mối liên hệ giữa bài học và mục tiêu lớn \\par hơn của lớp học.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="12000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Học sinh cần phải tạo mối liên hệ giữa những gì mình đang học ở thời điểm hiện tại \\par với những gì mình sẽ học trong tương lai.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="18000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Một cách hay để kết thúc bài học là liên kết trực tiếp với nội dung sẽ được dạy trong \\par bài học tiếp theo.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="4000" xmpDM:startTime="24000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Phong cách bán âm của ban nhạc giải thích rõ điều này ở phần kết bài hát của họ.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="4000" xmpDM:startTime="28000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Mọi sự khởi đầu mới đều bắt nguồn từ những sự khởi đầu kết thúc khác.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="34000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Hãy xem danh sách các chiến lược có thể được sử dụng để chuyển sang hướng \\par dẫn trong tương lai.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="14000" xmpDM:startTime="54000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Chúng ta hãy cùng xem hai ví dụ về một giáo viên chuyển sang hướng dẫn tiếp \\par theo khi kết thúc bài học.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="16000" xmpDM:startTime="68000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Đọc hai ví dụ và nhấp vào ví dụ mà bạn cho là hiệu quả hơn.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="84000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Ví dụ A là ví dụ hiệu quả hơn về quá trình chuyển đổi sang hướng dẫn trong tương \\par lai.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="6000" xmpDM:startTime="90000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Cả hai lựa chọn này đều liên kết thành công bài học với những gì học sinh sẽ học \\par vào ngày mai.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="4000" xmpDM:startTime="96000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Ví dụ A cũng tạo nên sự mong đợi về bài học sắp tới.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="8000" xmpDM:startTime="100000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Học sinh có thể không biết Emily Bronte là ai, vì vậy việc nói với các em rằng sẽ đọc \\par thơ của bà có lẽ sẽ chẳng có ý nghĩa gì với các em.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:duration="10000" xmpDM:startTime="108000" tscDM:valign="bottom" tscDM:halign="center"><xmpDM:name><rdf:Alt><rdf:li xml:lang="en-US">{\\rtf1 Trong phương án A, hãy thêm một chút hồi hộp bằng cách cho học sinh biết rằng \\par nhà thơ mà họ sẽ đọc là độc đáo và khác biệt.}</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                     <tsc:fgColor xmpG:red="255" xmpG:green="255" xmpG:blue="255"/><tsc:bgColor xmpG:red="0" xmpG:green="0" xmpG:blue="0"/></rdf:Description>\
               </rdf:li>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="Quiz" xmpDM:frameRate="f1000" xmpDM:trackName="Quiz" tscIQ:quizGuid="1CAF2289-1CDD-43B1-8909-4AD378F60B64" tscIQ:authoredEmail="bGVuaGhhYmFvdHJvbmdAZ21haWwuY29t" tscIQ:requireUserId="0" tscIQ:locale="en-US" tscIQ:reportMethod="APIANDSCORM" tscIQ:allowSkipQuiz="0" tscIQ:clientId="1CDF22D874AC443FBBB68075B4AE31CD" tscIQ:hideReplay="0" tscIQ:quizHash="1a4e3a59328ae908190f621ea7e84750">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:startTime="85200" tscIQ:feedback="1" tscIQ:questionSetName="Quiz 1"><tscIQ:questions><rdf:Seq><rdf:li><rdf:Description tscIQ:type="MC" tscIQ:id="0"><tscIQ:question>Chọn câu trả lời đúng</tscIQ:question><tscIQ:correctAnswer>1</tscIQ:correctAnswer><tscIQ:answerArray><rdf:Seq><rdf:li><rdf:Description tscIQ:orderId="0"><tscIQ:answer>A</tscIQ:answer></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:orderId="1"><tscIQ:answer>B</tscIQ:answer></rdf:Description></rdf:li></rdf:Seq></tscIQ:answerArray><tscIQ:feedback><rdf:Bag><rdf:li><rdf:Description tscIQ:reason="correct"><xmpDM:name><rdf:Alt><rdf:li>Đúng</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:reason="incorrect" tscIQ:jumpToTime="0"><xmpDM:name><rdf:Alt><rdf:li>Sai</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li></rdf:Bag></tscIQ:feedback></rdf:Description></rdf:li></rdf:Seq></tscIQ:questions></rdf:Description></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                     <tscIQ:QuizParams><rdf:Bag><rdf:li xmpDM:name="txtPrev" xmpDM:value="Quay lại"/><rdf:li xmpDM:name="txtNext" xmpDM:value="Đi tiếp"/><rdf:li xmpDM:name="txtAnswerQuestion" xmpDM:value="Trả lời câu hỏi"/><rdf:li xmpDM:name="txtSubmit" xmpDM:value="Trả lời"/><rdf:li xmpDM:name="txtReview" xmpDM:value="Xem lại"/><rdf:li xmpDM:name="txtReviewAnswer" xmpDM:value="Xem câu trả lời"/><rdf:li xmpDM:name="txtContinue" xmpDM:value="Tiếp tục"/></rdf:Bag></tscIQ:QuizParams></rdf:Description>\
               </rdf:li>\
            </rdf:Bag>\
         </xmpDM:Tracks>\
         <tscDM:controller>\
            <rdf:Description xmpDM:name="tscplayer">\
               <tscDM:parameters>\
                  <rdf:Bag>\
                     <rdf:li xmpDM:name="autohide" xmpDM:value="true"/><rdf:li xmpDM:name="autoplay" xmpDM:value="false"/><rdf:li xmpDM:name="loop" xmpDM:value="false"/><rdf:li xmpDM:name="searchable" xmpDM:value="true"/><rdf:li xmpDM:name="captionsenabled" xmpDM:value="false"/><rdf:li xmpDM:name="sidebarenabled" xmpDM:value="false"/><rdf:li xmpDM:name="unicodeenabled" xmpDM:value="false"/><rdf:li xmpDM:name="backgroundcolor" xmpDM:value="000000"/><rdf:li xmpDM:name="sidebarlocation" xmpDM:value="left"/><rdf:li xmpDM:name="endaction" xmpDM:value="stop"/><rdf:li xmpDM:name="endactionparam" xmpDM:value="true"/><rdf:li xmpDM:name="locale" xmpDM:value="en-US"/></rdf:Bag>\
               </tscDM:parameters>\
               <tscDM:controllerText>\
                  <rdf:Bag>\
                  </rdf:Bag>\
               </tscDM:controllerText>\
            </rdf:Description>\
         </tscDM:controller>\
         <tscDM:contentList>\
            <rdf:Description>\
               <tscDM:files>\
                  <rdf:Seq>\
                     <rdf:li xmpDM:name="0" xmpDM:value="module20_4.mp4"/><rdf:li xmpDM:name="1" xmpDM:value="module20_4.zip"/><rdf:li xmpDM:name="2" xmpDM:value="module20_4_First_Frame.png"/></rdf:Seq>\
               </tscDM:files>\
            </rdf:Description>\
         </tscDM:contentList>\
      </rdf:Description>\
   </rdf:RDF>\
</x:xmpmeta>';
